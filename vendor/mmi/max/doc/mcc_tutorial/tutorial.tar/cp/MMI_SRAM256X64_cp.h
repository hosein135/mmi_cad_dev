* Header for Critical Path of MMI_SRAM256X64.

********************** begin header *****************************

* Header file for TSMC 2.5V 0.25 um logic process

.OPTIONS post ACCT OPTS lvltim=2
.option nomod

.option gmindc=   10.0p       

.options ADM_V_SUPPLY=2.5
*.options ADM_ACCURACY=10
*.options ADM_MODE=exp
.options ADM_MODE=acs
*.options ADM_MAXSTEP=10p
.options ignore_meas=0
*.param temper = 105

**################################################
* Corners are TT, SS, FF, SF, FS
.lib '/home/cad/mmi_local/sue/tech/tsmc25.l' TT
**################################################

.PARAM vddp=2.25		$ VDD voltage

VDD vdd 0 DC vddp 

.TEMP 110
.TRAN 10p 22n
*.TRAN 10p 10n
*********************** end header ******************************

*** NEED TO FIX THIS PATH ***
.INCLUDE '<path>/mcc/sram/max/MMI_SRAM256X64_cp.sp'

* Input stimulus
Va0 a[0] gnd vddp
Va1 a[1] gnd vddp
Va2 a[2] gnd vddp
Va3 a[3] gnd vddp
Va4 a[4] gnd vddp
Va5 a[5] gnd vddp
Va6 a[6] gnd vddp
Va7 a[7] gnd vddp

* W - R - W - R

.PARAM cycle=5.0e-9
Vclk clk gnd pulse 0V vddp 1ns 200ps 200ps '0.6*cycle - 200ps' cycle

Vmemenable memenable gnd vddp
Vwenable wenable gnd pulse 0V vddp 0ns 200ps 200ps '0.5*cycle - 200ps' '2*cycle'
Vwdata[63] wdata[63] gnd pulse vddp 0V 0ns 200ps 200ps '0.5*cycle - 200ps' '4*cycle'

* Output loads
Crdata[63] rdata[63] gnd 100fF

.END

