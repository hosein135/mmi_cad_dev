# Micro Magic MegaCell Compiler Control File.

# Default generator name in "MC Build" menu.
set MC(default_generator) sram
# Parameters associated with this generator so the user can change them
# in the menu.
set MC(sram,parameters) "ROWS COLS"

#set MC(sram,prefix) "MMI_"
#set MC(sram,suffix) ""
#set MC(sram,name) ""

set MC(sram,prefix) "MMI_SRAM_"
set MC(sram,suffix) {_[expr $ROWS * 8]X[expr $COLS / 8]}
set MC(sram,name) {MMI_SRAM[expr $ROWS * 8]X[expr $COLS / 8]}

# Parameters that control SRAM size and shape.
set ROWS 16
set COLS 16

# layer name to be use for bbox of cells
set MC(boundary) prb

set MACRO(cell_4) {CELL {{mmi_sram_cell fy} {mmi_sram_cell r180}}
  {mmi_sram_cell {mmi_sram_cell fx}}}

set MACRO(half_row2) {CELL {{REPEAT [expr $COLS/4] cell_4}}}
set MACRO(wl_buf2) {CELL {{mmi_sram_wl_buf fy}} mmi_sram_wl_buf}
set MACRO(wl_buf2x2) {CELL {{mmi_sram_wl_buf2x fy}} mmi_sram_wl_buf2x}
set MACRO(row) {CELL {wl_buf2 half_row2 wl_buf2x2 half_row2 {wl_buf2 fx}}}

set MACRO(core) {CELL {REPEAT [expr $ROWS/2] row}}

set MACRO(wld2) {{{mmi_sram_wld fy}} mmi_sram_wld}
set MACRO(wlds) {CELL {REPEAT [expr $ROWS/2] wld2}}

set MACRO(wbld8) {{{mmi_sram_wbld fy} {mmi_sram_wbld_m r180 mmi_sram_wbld_1} \
       {mmi_sram_wbld fy} {mmi_sram_wbld_m r180 mmi_sram_wbld_3}} \
  {{mmi_sram_wbld fx} {mmi_sram_wbld_m "" mmi_sram_wbld_5} \
       {mmi_sram_wbld fx} {mmi_sram_wbld_m "" mmi_sram_wbld_7}}}


set MACRO(sa4) {CELL mmi_sram_read_mux4 {{REPEAT 4 mmi_sram_sa}}}
set MACRO(bottom4) {CELL sa4 mmi_sram_wdata_latch wbld8}

set MACRO(bottom) {CELL {mmi_sram_bottom_bufs {REPEAT [expr $COLS/16] bottom4} \
			     mmi_sram_bottom_bufs {mmi_sram_bottom_bufs fx} \
			     {REPEAT [expr $COLS/16] bottom4} \
			     {mmi_sram_bottom_bufs fx}}}

# top level SRAM
#set MACRO(sram_int) {{{SPACE [expr [mc_width mmi_sram_wl_buf] - [mc_width mmi_sram_bottom_bufs]]} bottom} {core TOP wlds}}
set MACRO(sram_int) {{{SPACE 2.5} bottom} {core TOP wlds}}
set MACRO(sram) {CELL {sram_int {SPACE -35.7} mmi_sram_base}}

# program command takes the following arguments
# 
# program \
#   <list of signals to alternatively connect> \
#   <signal to connect to> \
#   <format of name of cell to connect in> \
#   <number of cells to make connections in> \
#   <number of cells to programs before moving to next signal>

# setup the procedure that programs the word line decoders with
# unique addresses.  Note that this has to be named:
#          program_<gen_name>

proc program_sram {} {
  
  global ROWS COLS

  if {$ROWS <= 16} {
    # tie off the hi order address
    program_cell _TOP_
    puts "Tying off a\[7\]..."
    program gnd1 a\[7\] mmi_sram_base_0 1 1
  }

  program_cell bottom4

  # program the write addresses
  program \
      {write_0_feed write_1_feed write_2_feed write_3_feed
        write_3_feed write_2_feed write_1_feed write_0_feed} \
      write \
      "mmi_sram_wbld_%d" \
      8 \
      1

  # program the word lines
  program_cell wlds

  program \
      {en_a3_0_feed en_a3_1_feed} \
      in2 \
      "mmi_sram_wld_%d" \
      $ROWS \
      1

  program \
      {a4_a5_0_feed a4_a5_1_feed a4_a5_2_feed a4_a5_3_feed} \
      in0 \
      "mmi_sram_wld_%d" \
      $ROWS \
      2

  program \
      {a6_a7_0_feed a6_a7_1_feed a6_a7_2_feed a6_a7_3_feed} \
      in1 \
      "mmi_sram_wld_%d" \
      $ROWS \
      8
}


proc setup_sram {} {

  global ROWS COLS MC

  set MC(sram,propagate) $MC(sram,propagate,tmp)

  if {$ROWS > 16} {
    # propagate a[7]
    lappend MC(sram,propagate) {prop mmi_sram_base_0/a[7]}
  }
}

# Controls port propagation.

# left | right | up | down (defaults to left if not defined)
set MC(default_propagate_direction) left

set MC(sram,propagate,tmp) {
  {count {mmi_sram_read_mux4/Dout rdata\[%d\]}} 
  {count {mmi_sram_wdata_latch/din wdata\[%d\]}}
  {prop mmi_sram_base_0/a[0] mmi_sram_base_0/a[1] mmi_sram_base_0/a[2]}
  {prop mmi_sram_base_0/a[3]}
  {prop mmi_sram_base_0/a[4] mmi_sram_base_0/a[5] mmi_sram_base_0/a[6]}
  {prop mmi_sram_base_0/memenable mmi_sram_base_0/wenable mmi_sram_base_0/clk}
  {prop mmi_sram_base_0/gnd mmi_sram_base_0/vdd}
}

# The "prop" command tells the MegaCell Compiler which pins to propagate.
# the "count" command allows the user to rename ports and enumerate them.

msg "SRAM Generator Loaded.\n"
