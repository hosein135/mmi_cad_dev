// SRAM test

// run with:
// verilog +lic_ncv +libext+.v -y v.lib test_sram128x64.v

// remember to set your library
// setenv LD_LIBRARY_PATH    "${VENV_LD_LIB_PATH}:/usr/dt/lib:/usr/openwin/lib:$LD_LIBRARY_PATH" 


// units of time and time resolution for this run
`timescale 1ns / 1ns

// include files
`include "../max/MMI_SRAM128X64.v"

// number of address to check
`define MAX_ADDRESS 128
//`define MAX_ADDRESS 6


module test;

   reg [12:0]	count, address, last_a, temp;
   reg [12:0]	err_count;

   reg		clk, memenable, wenable, write, last_wenable;

   reg [6:0]	a;

   wire [63:0]	rdata;
   
   reg [63:0]	wdata;


// instantiate the sram

   MMI_SRAM128X64 sram (
			.clk(clk), 
			.a(a),
			.memenable(memenable),
			.wenable(wenable),
			.rdata(rdata),
			.wdata(wdata)
			);

   initial begin
      // dump to verilog.dump
      $dumpvars;

      count = 0;
      err_count = 0;
      address = 0;
      write = 1;

      clk = 0;

      memenable = 1;

      a = 0;
      wenable = 1;
      wdata = 0;
   end

   always begin
      #10 clk = ~clk;
    end

   always @(posedge clk) begin
     // this is confusing since this is the output data from the
     // previous cycle
     $display("a=%d, wen=%d, w=%d, r=%d", a, wenable, wdata, rdata);

      // check if answer if correct
      if (!last_wenable) begin
	 if (last_a !== rdata) begin
	    $display("ERROR, read address = %d, data = %d",last_a,rdata);
	    err_count = err_count + 1;
	 end

//	 $display("checked = %d -> %d",last_a,temp);	 
      end

      last_a = a;
      last_wenable = wenable;
   end

   always @(negedge clk) begin
      a = address;
      wenable = write;

      if (write) begin
	 // first pass, write the memory
	 count = count + 1;
	 address = address + 1;
	 
	 wdata = a;

	 if (address >= `MAX_ADDRESS) begin
	    // done writing
	    write = 0;
	    address = 0;
	 end
      end
      else begin
	 // second pass, read the memory
	 address = address + 1;

	 if (address >= `MAX_ADDRESS) begin
	    // done
#40	    $display("%d errors in %d addresses",err_count,count);
	    $finish;      
	 end
      end
   end

endmodule
