// reset generator
 
module mmi_sram_rgen (reset_L, latch, in, clk);

	parameter	delay = 2;

	input	in, clk;
	output	reset_L, latch;
	reg	reset_L;

	assign latch = in;

	always begin
	  @(clk or in) begin
	    if (!clk & !in)
	      #delay reset_L = 1;
	    else if (in)
	      #delay reset_L = 0;
          end
	end

endmodule
