// write predecoder driver behavioral model 
 
module mmi_sram_wr_predecode (pre, in0, in1, in2, enable);

	input	in0, in1, in2, enable;
	output	pre;

	wire	int;

        // predecoder/driver
	assign int = in0 & in1 & in2;
	assign pre = !(enable & int);

endmodule
