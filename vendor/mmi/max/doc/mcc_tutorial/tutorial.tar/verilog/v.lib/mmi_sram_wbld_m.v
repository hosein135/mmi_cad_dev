// write bit line driver (mirrored)

module mmi_sram_wbld_m (bl, bl_L, write, d, d_L);

	input	write, d, d_L;
	output	bl, bl_L;
	trireg	bl, bl_L;

	supply0	GND;

	// drive
	nmos #1 n1 (bl, GND, !write & !d);
	nmos #1 n2 (bl_L, GND, !write & !d_L);

endmodule
