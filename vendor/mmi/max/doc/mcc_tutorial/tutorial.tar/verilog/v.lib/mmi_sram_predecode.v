// predecoder driver behavioral model 
 
module mmi_sram_predecode (pre, in0, in1);

	input	in0, in1;
	output	pre;

        // predecoder/driver
	assign pre = in0 & in1;

endmodule
