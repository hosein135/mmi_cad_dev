// dual output latch
 
module mmi_sram_wdata_latch (d, d_L, din, clk);

	parameter	delay = 1;

	input	din, clk;
	output	d, d_L;
	reg	d, d_L;

	always begin
	  @(clk) begin
	    if (!clk) begin
	      #delay d = din;
	      d_L = !d;
            end
          end
	end

endmodule
