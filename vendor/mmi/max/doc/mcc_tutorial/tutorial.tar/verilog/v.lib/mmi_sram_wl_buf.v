// word line buffer
 
module mmi_sram_wl_buf (wl, wl_in);

	input	wl_in;
	output	wl;

	assign wl = wl_in;

endmodule
