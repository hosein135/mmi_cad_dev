// 6T sram cell behavioral model

module mmi_sram_cell (wl, bl, bl_L);

	input	wl;
	inout	bl, bl_L;

	trireg	q;

	// reading
        bufif1 #1 n1 (bl, q, wl); 
        bufif1 #1 n2 (bl_L, !q, wl); 

//	rnmos n1 (bl, q, wl);
//	rnmos n2 (bl_L, !q, wl);

	// writing
	bufif1 bf1 (q, bl, wl & (bl ^ bl_L));

endmodule
