// write enable predecoder and buffer
 
module mmi_sram_wen_buf (enable, memenable, wenable);

	input	memenable, wenable;
	output	enable;

	assign enable = memenable & wenable;

endmodule
