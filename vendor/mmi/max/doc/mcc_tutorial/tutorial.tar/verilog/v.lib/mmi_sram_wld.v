// world line decoder driver
 
module mmi_sram_wld (wl, in0, in1, in2);

	input	in0, in1, in2;
	output	wl;

        // decoder/driver
	assign #2 wl = in0 & in1 & in2;

endmodule
