// sense amp, mux, bit line precharge

module mmi_sram_sa (Dout, sense_L, sel, bl0, bl0_L, bl1, bl1_L);

	input	sense_L, sel;
	inout	bl0, bl0_L, bl1, bl1_L;
	output	Dout;

	reg	q, q_L;

	wire	pre_L;

	supply1	VDD;

	// bl equil
	assign #1 pre_L = sense_L;
	rpmos p1 (bl0, VDD, pre_L);
	rpmos p2 (bl0_L, VDD, pre_L);
	rpmos p3 (bl1, VDD, pre_L);
	rpmos p4 (bl1_L, VDD, pre_L);

	// mux, sense amp
	always begin
	  @(negedge sense_L) begin
	      q_L = !((sel & bl1) | (!sel & bl0));
	      q = !((sel & bl1_L) | (!sel & bl0_L));
	  end
	end

	// precharge sa
	always begin
	  @(sense_L) begin
	    if (sense_L) begin
	      q_L = VDD;
	      q = VDD;
	    end
	  end
	end

	// should check that q != q_L
	buf #1 buf1 (Dout, !q_L);

endmodule
