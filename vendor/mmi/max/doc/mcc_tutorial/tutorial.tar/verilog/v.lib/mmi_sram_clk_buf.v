// internal clock buffer
 
module mmi_sram_clk_buf (clk_int, wd_clk, clk);

	input	clk;
	output	clk_int, wd_clk;

	assign clk_int = clk;
	assign wd_clk = clk;

endmodule
