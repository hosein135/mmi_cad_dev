// 4:1 read mux
 
module mmi_sram_read_mux4 (Dout, in0, in1, in2, in3, sel0, sel1);

	input	in0, in1, in2, in3, sel0, sel1;
	output	Dout;

	assign Dout = ((in0 & !sel0) | (in1 & sel0)) & !sel1 | ((in2 & !sel0) | (in3 & sel0)) & sel1;

endmodule
