// dual output flip flop
 
module mmi_sram_ffd (q,q_,d,clk);

	parameter	delay = 1;

	input	d, clk;
	output	q, q_;
	reg	q, q_;

	always begin
	  @(posedge clk) begin
	    #delay q = d;
	    q_ = !q;
          end
	end

endmodule
