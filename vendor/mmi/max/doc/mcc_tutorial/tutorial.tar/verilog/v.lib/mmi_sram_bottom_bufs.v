// latch and select buffers
 
module mmi_sram_bottom_bufs (sense_L, sense_L_in, sel, sel_in);

	input	sense_L_in, sel_in;
	output	sense_L, sel;

	assign sense_L = sense_L_in;
	assign sel = sel_in;

endmodule
