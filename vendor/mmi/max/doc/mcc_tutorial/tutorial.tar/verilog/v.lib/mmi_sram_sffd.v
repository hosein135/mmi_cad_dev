// special dual output flip flop with reset
 
module mmi_sram_sffd (q, q_, d, clk, reset_L);

	parameter	delay = 1;

	input	d, reset_L, clk;
	output	q, q_;
	reg	q, q_;

	always begin
	  @(posedge clk) begin
	    #delay q = d;
	    q_ = !q;
          end
	end

	always begin
	  @(clk or reset_L) begin
	    if (!clk | !reset_L) begin
	      #delay q = 0;
	      q_ = q;
            end
          end
	end

endmodule
