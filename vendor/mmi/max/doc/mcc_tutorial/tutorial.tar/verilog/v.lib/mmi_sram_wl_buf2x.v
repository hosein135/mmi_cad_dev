// word line buffer -- 2x
 
module mmi_sram_wl_buf2x (wl, wl_in);

	input	wl_in;
	output	wl;

	assign wl = wl_in;

endmodule
