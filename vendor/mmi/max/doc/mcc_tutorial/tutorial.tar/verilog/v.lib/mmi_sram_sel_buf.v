// mux select buffer
 
module mmi_sram_sel_buf (sa_sel, in);

	input	in;
	output	sa_sel;

	assign sa_sel = in;

endmodule
